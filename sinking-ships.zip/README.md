This is a great sinking ships app

# quickstart
'''flask --app app.py --debug run''' 